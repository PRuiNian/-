#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")

/**
  * 
  * @author 赵培暄
  * @date ${DATE} ${TIME}
  * @version 1.0
  **/
public class ${NAME} {
}